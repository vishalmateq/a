
public class MaggiTest {

	public static void main(String[] args) {

	}

}


class Ingredients{
	
	private int maggiPacket;
	private int masalaPacket;
	private String type;
	private String water;
	
	
	void printIngredients(){
		System.out.println("----Disply Ingredients----");
		System.out.println();
	}
}