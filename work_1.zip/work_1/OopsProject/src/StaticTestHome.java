
public class StaticTestHome {

	public static void main(String[] args) {
		Branch s1  = new Branch();
		s1.shownoOfTest();
		
		s1.takeTestInsem();
		s1.shownoOfTest();
        
		
	}

}


class Branch{
  
	private int sem;
	private static int noOfTest;
   
	Branch()
	{
		
	}
	
	public static void shownoOfTest()
	{
		System.out.println("no of test in branch :  " +noOfTest );
	}
	
	private String name ;
	public Branch(String name, int sem) {
		super();
		this.name = name;
		this.sem = sem;
	}
	
    void takeTestInsem() {
    	noOfTest++;
    }
}
	
	
