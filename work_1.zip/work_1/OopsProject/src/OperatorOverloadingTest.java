
public class OperatorOverloadingTest {

	public static void main(String[] args) {
		
		System.out.println(10+20 +" sum is  " + (10+20) );
	}

}
