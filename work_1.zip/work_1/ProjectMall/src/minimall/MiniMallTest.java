package minimall;
import java.util.ArrayList;
import minimall.Laptop;
import java.util.Iterator;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;



public class MiniMallTest {

	public static void main(String[] args) {
		
		ChromaStore laptop = new Laptop(0.18, "HP", "i3" , "4GB", 40000);
		ChromaStore mobile = new Mobile(0.18, "Oneplus",  "4GB", "128GB", 25000 );
		Cloth cloth        = new Cloth("cotton", "black", "Shirt", 500);
		
		laptop.personChecking();
		mobile.personChecking();
		cloth.personChecking();
		
		ArrayList customerList = new ArrayList();
		
		Customer customer1=new Customer( "vishal","online",laptop);
		Customer customer2=new Customer("rohan","cash",mobile);
		Customer customer3=new Customer( "mohan","cash",cloth);
		
		customerList.add(customer1);
		customerList.add(customer2);
		customerList.add(customer3);
		
		
		Iterator iterat = customerList.iterator();
		
		try {
			FileOutputStream fileOutputStream = new FileOutputStream("CustInformation.txt", false); //true means append to the file

 			String str="";
			while(iterat.hasNext()) {
				Customer x = (Customer) iterat.next(); 
				str=x.toString()+"\n";
				byte array[] = str.getBytes(); //converts the string into a byte array
				fileOutputStream.write(array);
			}
			
			//System.out.println("String is written to the file");

			fileOutputStream.close();
		
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		} 
		
		
		
		customer1.run();
		customer2.run();
		customer3.run();
		
		
		
		
	}

}


class Billing{
	
	private String custName;
	private String product;
	private int price;
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Billing [custName=" + custName + ", product=" + product + ", price=" + price + "]";
	}
	
	public void showBill()
	{
		System.out.println("Name of Customer : " + custName);
		System.out.println("Name of product : " + product);
		System.out.println("Tocal billing price : " + price);
	}
	
}


class Customer extends Thread{
	

	private String name;
	private String paymentType;
	MiniMall mall;
	
	public Customer(String name, String paymentType, MiniMall mall) {
		super();
	
		this.name = name;
		this.paymentType = paymentType;
		this.mall = mall;
	}
	
	public void run()
	{
		Billing bill = this.customers(mall);
		System.out.println(mall);
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", paymentType=" + paymentType + ", mall=" + mall + "]";
	}

	Billing customers(MiniMall mall) {
		
		
		Billing Bill=new Billing();
		
		Bill.setCustName(this.name);
		Bill.setProduct(mall.getClass().getSimpleName());
		Bill.setPrice(mall.getPrice());
		
		return Bill;
	}
	
}
	
	
//Billing makeBill (Laptop lap , Mobile mobile , Cloth cloth){
//		
//		
//		Billing finalbill =new Billing();
//		
//		finalbill.setCustName(this.name);
//		finalbill.setProduct(mall.getClass().getSimpleName());
//		int finalCost = (lap.getPrice()) +(mobile.getPrice() + cloth.getPrice());
//		finalbill.setPrice( finalCost);
//	
//		return finalbill;
//		
//        }
//}


