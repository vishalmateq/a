
public class FinalMethodTest {
	public static void main(String[] args) {
		
		Chess chess = new GraphicalChess();
		chess.moveKnight();
	
	}
}

class Game{
	static void upload(Chess chess)
	{
		System.out.println("Game is being uploaded...");
		chess.moveKnight();
	}
}


class Chess
{
	final void moveKnight()
	{
		System.out.println(" Math moving by 2.5");
	}
	
	void moveRook()
	{
		System.out.println("Math horizonal / vertical vertical bidirecctional");
	}
}

class GraphicalChess extends Chess
{
	void moveMyKnight()
	{
		super.moveKnight();
		System.out.println("Grphical moving in L shape int a Frame..... 2.5 Step");
	}
	void moveRook()
	{
		System.out.println("Grphical moving any direction");
	}
}


class WebGraphicalChess extends Chess
{
	void moveMyKnight()
	{
		super.moveKnight();
		System.out.println("Grphical moving in L shape in a web..... 2.5 Step");
	}
}