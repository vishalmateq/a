
public class KiteTest {
	public static void main(String[] args) {

		Kite.showKiteCount();

		Kite kite1 = new Kite("vishal", "green", 50 ,true);
//		kite1.showKite();

		Kite kite2 = new Kite("Roshan", "green", 50,true);
//		kite2.showKite();

		Kite kite3 = new Kite("Rohan", "red", 50,true);
//		kite3.showKite();

//		Kite.showKiteCount();

		Kite kite4 = new Kite("om", "pink", 50,true);
//		kite4.showKite();

		Kite kite5 = new Kite("ram", "green", 50,true);
//		kite5.showKite();
		
		
		Kite.showKiteCount();
		kite1.kiteFight(kite3);
		Kite.showKiteCount();

	}
}

class Kite {
	private String owner;
	private String color;
	private int length;
	
	private boolean flying;
	private static int kiteCount;

	// function for static variable
	public static void showKiteCount() {
		System.out.println("Total Kites int the count  :" + kiteCount);
	}

	// constructor for assign value to object
	public Kite(String owner, String color, int length , boolean flying) {
		super();
		System.out.println("kite is created ");
		this.owner = owner;
		this.color = color;
		this.length = length;
		this.flying  = flying;
		kiteCount++;
	
	}

	void showKite() // non-static ac access and refer static
	{
		System.out.println("owner      :" + owner);
		System.out.println("color      :" + color);
		System.out.println("len        :" + length);
		System.out.println("kite count :" + kiteCount); // non static
		System.out.println("--------------------------");

	}
	
	/**
	 * @param ref
	 */
	/**
	 * @param ref
	 */
	void kiteFight(Kite ref) //kite4.kiteFight(kite5);
	{
		System.out.println( color +" :  Kite fight initiated with   :" +ref.color);
		
		for(int i = 1; i<=20; i++)
		{
			double value = Math.random()%10;
			System.out.println(i + "Kites are fighting" +value);
			if(value > 0.95)
			{
				kiteCount--;
				this.flying = false;
				System.out.println();
				break;
			}
			if(value<0.010)
			{
				kiteCount--;
				ref.flying=false;
				break;
			}
			
			if(value >= 0.30 && value<=0.33)
			{
				kiteCount--;
				kiteCount--;
				this.flying = false;
				ref.flying=false;
				break;
			}
		}
	}

	@Override
	public String toString() {
		return "Kite [owner=" + owner + ", color=" + color + ", length=" + length + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}