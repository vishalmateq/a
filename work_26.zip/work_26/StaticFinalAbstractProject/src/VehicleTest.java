
public class VehicleTest {

	public static void main(String[] args) {
		
		PetrolBike e = new PetrolBike();
		e.use();
		e.drive();
		e.ride();
		e.sound();

		System.out.println("==========");
		
		ElectricBike b = new ElectricBike();
		b.use();
		b.drive();
		b.ride();
		b.fule();
		
		System.out.println("==========");
		
		PetrolCar pc = new PetrolCar();
		pc.use();
		pc.drive();
		pc.ride();
		pc.milage();
		
		
		System.out.println("==========");
		
		
		ElectricCar ec = new ElectricCar();
		ec.use();
		ec.drive();
		ec.ride();
		ec.consume();
	}

}

interface Vechicle{
	void use();
}

abstract class TwoWheel implements Vechicle{
	abstract void drive();
}

abstract class SportBike extends TwoWheel{
	abstract void ride();
}

class PetrolBike extends SportBike{

	
	public void use() {
	
		System.out.println("using the Petrol bike...");
	}

	
	void ride() {
	
		System.out.println("riding the Petrolbike ..");
	}


	void drive() {
	
		System.out.println("diveing Petrolbike..");
	}
	void sound()
	{
		System.out.println("producing lound sond");
	}
	
}


class ElectricBike extends SportBike{

	
	public void use() {
		
		System.out.println("using the Electric bike...");
	}

	
	void ride() {
	
		System.out.println("riding the Electricbike ..");
	}


	void drive() {
	
		System.out.println("diveing Electric..");
	}
	
	void fule()
	{
		System.out.println("using electricity..");
	}
	
}



abstract class FourWheel implements Vechicle{
	abstract void drive();
}

abstract class SportCar extends FourWheel{
	abstract void ride();
}

class PetrolCar extends SportCar{

	
	public void use() {
	
		System.out.println("using the Petrol bike...");
	}

	
	void ride() {
	
		System.out.println("riding the Petrolbike ..");
	}


	void drive() {
	
		System.out.println("diveing Petrolbike..");
	}
	void milage()
	{
		System.out.println("low milage");
	}
	
}


class ElectricCar extends SportCar{

	
	public void use() {
		
		System.out.println("using the ElectricCar ...");
	}

	
	void ride() {
	
		System.out.println("riding the ElectricCar ..");
	}


	void drive() {
	
		System.out.println("diveing Electric Car..");
	}
	
	void consume()
	{
		System.out.println("conscume Electricity...");
	}
	
}