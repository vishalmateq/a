
public class AbstractTest {
    public static void main(String[] args) {
	
    	//abstract = partial 
    	GeometricalShape geoShape = new Square(5);
    	geoShape.calcArea();
    	geoShape.calPerimeter();
    	
    	System.out.println("============");
    	
    	geoShape = new Rectangle(5,3);
    	geoShape.calcArea();
    	geoShape.calPerimeter();
    	
    	
   }
}

abstract class GeometricalShape
{
	abstract void calcArea();  //METHOD WITHOUT BODY
	abstract void calPerimeter();
	
	void fillColor() {  //METHOD WITH BODY
		System.out.println("Filling color.......");
	}
}

class Square extends GeometricalShape
{
	int side;
	
	public int getSide() {
		return side;
	}

	public Square(int side) {
		super();
		this.side = side;
	}
	
	void calcArea() {
		float area = side *side;
		System.out.println("Area : " + area);
	}
	void calPerimeter() {
		float  perimeter = 4 * side;
		System.out.println("peri : " + perimeter);
	}
	
}


class Rectangle extends Square{
	int breadth;

	public Rectangle(int breadth ,int side) {
		super(side);
		this.breadth = breadth;
		
	}
	
	//The above method need not to be an madetory to 
	// implement in a child class
	
	void calcArea() {
		float area = getSide() * breadth;
		System.out.println("Area : " + area);
	}
	void calPerimeter() {
		float  perimeter = 2 *( getSide() + breadth);
		System.out.println("peri : " + perimeter);
	}
	
	
}