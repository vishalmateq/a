package jungle.house; //belong to

import jungle.cave.Tiger; //avail it here 

public class FarmeHouse {
	public static void main(String[] args) {
		
		Tiger tiger = new Tiger();
		
	}
}
