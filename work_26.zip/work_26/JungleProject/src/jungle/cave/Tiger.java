package jungle.cave;

public class Tiger {

	
	private void privateMethodA() {
		System.out.println("Tiger is privateMethodA");
	}
	
	protected void protectedMethodB() {
		System.out.println("Tiger is protectedMethodA");
	}
	
	public void publicMethodC() {
		System.out.println("Tiger is publicMethodA");
	}
	
	void defaultMethodD() {
		System.out.println("Tiger is publicMethodA");
	}
}
