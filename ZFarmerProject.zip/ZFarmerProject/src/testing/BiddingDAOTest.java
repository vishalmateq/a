package testing;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

//import service.BiddingDAOImplementation;
import dao.BiddingDAO;
import entities.BidderEntity;
import entities.BiddingEntity;
import service.BiddingDAOImplementation;

public class BiddingDAOTest {
	BiddingDAO biddingDao= new BiddingDAOImplementation();
//	BiddingDAO biddingDao;

//	public void BiddingDAOImplementation(BiddingDAO biddingDao) {
//		super();
//		this.biddingDao = biddingDao;
//	}

	
	
	@Test
	
	public void selectMaxBiddingAmountTest() {
		 System.out.println("Test started..");
			Assertions.assertTrue(biddingDao!=null);
			System.out.println("Got the DAO : "+biddingDao);
			
			/*List<BiddingEntity> bidList = biddingDao.selectAllBiddingDetails(304);
			for (BiddingEntity biddingEntity : bidList) {
				System.out.println("bidding entity : "+biddingEntity);
			}*/
			int maxBidAmt = biddingDao.getMaxBiddingAmountForCrop(304);
			
		//	biddingEntityObj.setBidAmount(biddingDao.getMaxBiddingAmountForCrop(302));
		//	System.out.println("run");
			
//			System.out.println();
			System.out.println("BidderEntity Obj : "+maxBidAmt);

			System.out.println("Test over...");
		
	}
}
