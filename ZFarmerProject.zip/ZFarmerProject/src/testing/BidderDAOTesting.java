package testing;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import dao.BidderDAO;
import entities.BidderEntity;

import service.BidderDAOImplementation;

public class BidderDAOTesting {
   BidderDAO bidderDao=new BidderDAOImplementation();
   @Test
   public void selectBidder() {
	   System.out.println("Test started..");
		Assertions.assertTrue(bidderDao!=null);
		System.out.println("Got the DAO : "+bidderDao);

		BidderEntity bidderEntityObj = bidderDao.selectBidder(701);
		
		System.out.println("BidderEntity Obj : "+bidderEntityObj);

		System.out.println("Test over...");
   }
   
}
