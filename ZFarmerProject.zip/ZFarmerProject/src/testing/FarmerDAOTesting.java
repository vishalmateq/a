package testing;
import entities.FarmerEntity;

import service.FarmerDAOImplementation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.*;

public class FarmerDAOTesting {

	
	FarmerDAO farmerDAO=new FarmerDAOImplementation();
	@Test
public void selectTest() {
		
		System.out.println("Test started..");
		Assertions.assertTrue(farmerDAO!=null);
		System.out.println("Got the DAO : "+farmerDAO);

		FarmerEntity farmerEntityObj = farmerDAO.selectFarmer(101);
		
		System.out.println("FarmerEntity Obj : "+farmerEntityObj);

		System.out.println("Test over...");
	}
}

