//package com.farmer.pages;


import java.awt.EventQueue;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.Event;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.*;

import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;

import entities.BiddingEntity;
import entities.CropDetailsEntity;
import entities.FarmerEntity;
import service.BiddingDAOImplementation;
import service.CropDAOImplementation;
import service.FarmerDAOImplementation;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class WelcomeBidderPage extends JFrame {

	private JPanel contentPane;
	private JTextField txtHello;
	private JTable table;
	private JTable table_1;
	DefaultTableModel model;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FarmerPage frame = new FarmerPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
		
	
		
	}

	/**
	 * Create the frame.
	 */
	
	public WelcomeBidderPage() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 850);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 235, 215));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.setBackground(new Color(128, 128, 128));
		btnNewButton.setForeground(new Color(128, 0, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(993, 23, 160, 46);
		contentPane.add(btnNewButton);
		
		JButton btnViewSoldCrop = new JButton("Bid Crop");
		btnViewSoldCrop.setBackground(new Color(0, 128, 64));
		btnViewSoldCrop.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnViewSoldCrop.setBounds(771, 24, 184, 46);
		contentPane.add(btnViewSoldCrop);
		
//		
//		  
		JButton btnNewButton_1 = new JButton("Back");
		
		btnNewButton_1.setBackground(new Color(205, 92, 92));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setBounds(1035, 139, 89, 23);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.setVisible(false);
		
		JPanel panel = new JPanel();
		panel.setBounds(657, 248, 496, 349);
		contentPane.add(panel);
		panel.setLayout(null);
//		panel.setVisible(false);
		
		JLabel lblNewLabel = new JLabel("Crop ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(35, 14, 105, 27);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(251, 11, 216, 39);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblCropName = new JLabel("Crop Name");
		lblCropName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCropName.setBounds(35, 69, 105, 27);
		panel.add(lblCropName);
		
		JLabel lblBidAmount = new JLabel("Bid Amount");
		lblBidAmount.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBidAmount.setBounds(35, 223, 115, 27);
		panel.add(lblBidAmount);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(251, 61, 216, 39);
		panel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(251, 220, 216, 39);
		panel.add(textField_2);
		
		JButton btnNewButton_2 = new JButton("Bid");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FarmerDAO farmerDAOObject=new FarmerDAOImplementation();
				FarmerEntity farmerEntity=new FarmerEntity();
				
				BiddingDAO biddingDAOObject=new BiddingDAOImplementation();
				BiddingEntity biddingEntity=new BiddingEntity();
				
				biddingEntity.setCrop_id(Integer.parseInt(textField.getText()));
				biddingEntity.setCrop_name(textField_1.getText());
				biddingEntity.setBidder_id(Integer.parseInt(textField_4.getText()));
				biddingEntity.setBidAmount(Integer.parseInt(textField_2.getText()));
				
				biddingDAOObject.insertBiddingDetalis(biddingEntity);
				
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.setBounds(73, 299, 133, 39);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("Cancel");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.setVisible(false);
			}
		});
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2_1.setBounds(299, 299, 133, 39);
		panel.add(btnNewButton_2_1);
		
		JLabel lblBaseAmount = new JLabel("Base Amount");
		lblBaseAmount.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBaseAmount.setBounds(21, 117, 143, 27);
		panel.add(lblBaseAmount);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(251, 117, 216, 39);
		panel.add(textField_3);
		
		JLabel lblBidderId = new JLabel("Bidder ID");
		lblBidderId.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblBidderId.setBounds(47, 171, 93, 27);
		panel.add(lblBidderId);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(251, 170, 216, 39);
		panel.add(textField_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 186, 637, 462);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int selectedIndex=table_1.getSelectedRow();
				textField.setText(model.getValueAt(selectedIndex, 0).toString());
				textField_1.setText(model.getValueAt(selectedIndex, 1).toString());
				textField_3.setText(model.getValueAt(selectedIndex, 4).toString());
			}
		});
		model=new DefaultTableModel();
		Object[] column= {"Crop ID","Crop Name","Fertilizer","Quantity","Base Price"};
//		Object[] row= new Object[0];
		model.setColumnIdentifiers(column);
		table_1.setModel(model);
		
		CropDAO cropDAOObject=new CropDAOImplementation();
	    CropDetailsEntity cropDetailEntity=new CropDetailsEntity();
//	    cropDetailEntity=cropDAOObject.selectCrop();
		List<CropDetailsEntity> cropList=cropDAOObject.selectAllCropNotSold();
		for (int i = 0; i < cropList.size(); i++) 
		{
			CropDetailsEntity cropDetailsEntity=cropList.get(i);
			long intID=cropDetailsEntity.getCropId();
			String strName=cropDetailsEntity.getCropName();
			String strFer=cropDetailsEntity.getFertilizerType();
			String quantity=cropDetailsEntity.getQuntity();
			int val=Integer.parseInt(quantity)*100  ;
			Object row[]= {intID,strName,strFer,quantity,val};
			model.addRow(row);
		}
		scrollPane.setViewportView(table_1);
		
		JButton btnNewButton_1_1 = new JButton("Available Crops");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1.setBackground(new Color(0, 128, 64));
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1_1.setBounds(550, 24, 170, 46);
		contentPane.add(btnNewButton_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_1.setBounds(29, 31, 89, 28);
		contentPane.add(lblNewLabel_1);
		
		
		
	}
	void showTexFeild(String str) {
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(126, 41, 49, 14);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		contentPane.add(lblNewLabel_2);
		lblNewLabel_2.setText(str);
	}
}
