 

public class EmailValidator  {
	
}
